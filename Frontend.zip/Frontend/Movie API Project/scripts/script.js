const HOST = "http://localhost:8080";
function getAllMovies(){
    $.ajax({
        method: "get",
        url: `${HOST}/movie/`,
    })
    .done((response) =>{
        document.getElementById("first-movie").value = response.title;
    })
    .fail((xhrObj) => {
        alert(xhrObj);
    });
}