const HOST = "http://localhost:8080";


function getAllMovies() {
    $.ajax({
        method: "get",
        url: `${HOST}/movies/`,
    })
        .done((response) => {

        })
        .fail((xhrObj) => {
            if (xhrObj && xhrObj.responseJSON && xhrObj.responseJSON.message)
                alert(xhrObj.responseJSON.message);
            if (xhrObj && xhrObj.responseText) {
                alert(xhrObj.responseText);
            }
        });
}

function getMovieById() {
    const moviesId = document.getElementById("movie-id").value;
    $.ajax({
        method: "get",
        url: `${HOST}/movies/find/${moviesId}`,
    })
        .done((response) => {
            document.getElementById("movie-title").value = response.title;
            document.getElementById("movie-genre").value = response.genre;
            document.getElementById("movie-year").value = response.year;
            document.getElementById("movie-rating").value = response.rating;
            document.getElementById("movie-director").value = response.director;
            document.getElementById("movie-cast").value = response.cast;
        })
        .fail((xhrObj) => {
            if (xhrObj && xhrObj.responseJSON && xhrObj.responseJSON.message)
                alert(xhrObj.responseJSON.message);
            if (xhrObj && xhrObj.responseText) {
                alert(xhrObj.responseText);
            }
        });
}

function createMovie() {
    const title = document.getElementById("new-movie-title").value;
    const genre = document.getElementById("new-movie-genre").value;
    const year = document.getElementById("new-movie-year").value;
    const rating = document.getElementById("new-movie-rating").value;
    const director = document.getElementById("new-movie-director").value;
    const cast = document.getElementById("new-movie-cast").value;

    $.ajax({
        method: "post",
        url: `${HOST}/movies/`,
        data: JSON.stringify({
            'title': title,
            'genre': genre,
            'year': year,
            'rating': rating,
            'director': director,
            'cast': cast,
        }),
        headers: {
            'Accept': "application/json",
            "Content-Type": "application/json",
        },
    })
        .done((response) => {
            alert("Movie created");
        })
        .fail((xhrObj) => {
            if (xhrObj && xhrObj.responseJSON && xhrObj.responseJSON.message)
                alert(xhrObj.responseJSON.message);
            if (xhrObj && xhrObj.responseText) {
                alert(xhrObj.responseText);
            }
        });
}

function updateMovie() {
    const moviesId = document.getElementById("update-movie-id").value;
    const title = document.getElementById("update-movie-title").value;
    const genre = document.getElementById("update-movie-genre").value;
    const year = document.getElementById("update-movie-year").value;
    const rating = document.getElementById("update-movie-rating").value;
    const director = document.getElementById("update-movie-director").value;
    const cast = document.getElementById("update-movie-cast").value;

    $.ajax({
        method: "put",
        url: `${HOST}/movies/find/${moviesId}`,
        data: JSON.stringify({
            title: title,
            genre: genre,
            year: year,
            rating: rating,
            director: director,
            cast: cast,
        }),
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
        },
    })
        .done((response) => {
            alert("Movie updated");
        })
        .fail((xhrObj) => {
            if (xhrObj && xhrObj.responseJSON && xhrObj.responseJSON.message)
                alert(xhrObj.responseJSON.message);
            if (xhrObj && xhrObj.responseText) {
                alert(xhrObj.responseText);
            }
        });
}

function deleteMovie() {
    const moviesId = document.getElementById("delete-movie-id").value;
    $.ajax({
        method: "delete",
        url: `${HOST}/movies/find/${moviesId}`,
    })
        .done((response) => {
            alert("Movie deleted");
        })
        .fail((xhrObj) => {
            if (xhrObj && xhrObj.responseJSON && xhrObj.responseJSON.message)
                alert(xhrObj.responseJSON.message);
            if (xhrObj && xhrObj.responseText) {
                alert(xhrObj.responseText);
            }
        });
}
