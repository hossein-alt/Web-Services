package jac.webservice.application.service;

import jac.webservice.application.exception.InvalidRatingException;
import jac.webservice.application.exception.MovieNotFoundException;
import jac.webservice.application.model.Movies;
import jac.webservice.application.repository.MoviesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

import static jac.webservice.application.constant.ErrorMessages.INVALID_RATINGS_MESSAGE;

@Component
public class MoviesService {
    @Autowired
    private MoviesRepository repository;

    public List<Movies> getAllMovies() {
        return repository.getAllMovies();
    }

    public Movies getMoviesById(Long moviesId) {
        Movies movies = repository.getMoviesById(moviesId);
        if (movies == null) {
            throw new MovieNotFoundException(moviesId.toString());
        }
        return movies;
    }

    public Long saveMovies(Movies movies) {
        if (movies.getRating() > 10 || movies.getRating() < 1) {
            throw new InvalidRatingException(INVALID_RATINGS_MESSAGE);
        }
        return repository.saveMovies(movies);
    }

    public void updateMovies(Long moviesId, Movies movies) {
        if (movies.getRating() > 10 || movies.getRating() < 1) {
            throw new InvalidRatingException(INVALID_RATINGS_MESSAGE);
        }
        repository.updateMovies(moviesId, movies);
    }

    public void deleteMovies(Long moviesId) {
        repository.deleteMovies(moviesId);
    }
}
