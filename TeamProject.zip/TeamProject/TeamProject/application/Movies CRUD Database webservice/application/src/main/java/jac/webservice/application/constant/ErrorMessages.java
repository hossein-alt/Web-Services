package jac.webservice.application.constant;

public class ErrorMessages {
    public static final String MOVIE_NOT_FOUND_MESSAGE = "The movie cannot be found with moviesId = ";
    public static final String INVALID_RATINGS_MESSAGE = "The rating needs to be between 1 and 10";
}
