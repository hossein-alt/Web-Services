package jac.webservice.application.api;

import jac.webservice.application.exception.InvalidRatingException;
import jac.webservice.application.model.Movies;
import jac.webservice.application.service.MoviesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/movies")
@CrossOrigin(origins = "http://127.0.0.1:5500")
public class MoviesController {
    @Autowired
    private MoviesService service;

    @GetMapping("/")
    public ResponseEntity<List<Movies>> getAll() {
        return new ResponseEntity<>(service.getAllMovies(), HttpStatus.OK);
    }

    @GetMapping("/find/{moviesId}")
    public ResponseEntity<Movies> getMoviesById(@PathVariable Long moviesId) {
        try {
            if (moviesId < 0) {
                return new ResponseEntity("The id cant be less than 0", HttpStatus.BAD_REQUEST);
            }
            Movies movie = service.getMoviesById(moviesId);
            return new ResponseEntity<>(movie, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/")
    public ResponseEntity<Long> createMovies(@RequestBody Movies movies) {
        try {
            return new ResponseEntity<>(service.saveMovies(movies), HttpStatus.CREATED);
        } catch (InvalidRatingException ratingException) {
            return new ResponseEntity(ratingException.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/find/{moviesId}")
    public ResponseEntity<Void> updateMovies(@PathVariable Long moviesId, @RequestBody Movies movies) {
        try {
            service.updateMovies(moviesId, movies);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception exception) {
            return new ResponseEntity(exception.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/find/{moviesId}")
    public ResponseEntity<Void> deleteMovies(@PathVariable Long moviesId) {
        try {
            service.deleteMovies(moviesId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception exception) {
            return new ResponseEntity(exception.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
}
