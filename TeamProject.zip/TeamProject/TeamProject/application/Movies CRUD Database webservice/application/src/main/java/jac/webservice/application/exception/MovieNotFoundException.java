package jac.webservice.application.exception;

import static jac.webservice.application.constant.ErrorMessages.MOVIE_NOT_FOUND_MESSAGE;

public class MovieNotFoundException extends RuntimeException {
    public MovieNotFoundException(String moviesId) {
        super(MOVIE_NOT_FOUND_MESSAGE + moviesId);
    }
}
