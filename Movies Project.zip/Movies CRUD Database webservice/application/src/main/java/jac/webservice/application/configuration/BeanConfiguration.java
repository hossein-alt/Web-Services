package jac.webservice.application.configuration;

import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanConfiguration {

//    @Bean
//    public JdbcTemplate jdbcTemplate(){
//        return new JdbcTemplate();
//    }
}
